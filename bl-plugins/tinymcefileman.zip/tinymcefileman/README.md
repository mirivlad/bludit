TinyMCEfileman - plugin for Bludit CMS. 
The plugin implements TinyMCE editor  for formatting content with a built-in file manager RESPONSIVEfilemanager
