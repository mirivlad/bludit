Плагин для CMS Bludit реализующий ленту RSS подходящую для генерации страниц Yandex Turbo. 

Подробнее о технологии yandex Turbo читайте тут: https://tech.yandex.ru/turbo/doc/concepts/index-docpage/
